import styled from 'styled-components/'

export const JobSpecifiedMainCon = styled.div`
  background-color: #000000;
  min-height: 100vh;
  max-height: 100%;
  width: 100%;
`
export default JobSpecifiedMainCon
