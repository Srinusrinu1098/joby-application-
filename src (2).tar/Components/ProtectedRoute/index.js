import Cookies from 'js-cookie'
import {Redirect, Route} from 'react-router-dom'

const ProtectedRoute = ({component: Component, ...restProps}) => {
  const jwtToken = Cookies.get('Token')

  if (jwtToken === undefined) {
    return <Redirect to="/login" />
  }
  return (
    <Route
      {...restProps}
      render={props => <Component {...props} {...restProps} />}
    />
  )
}
export default ProtectedRoute
